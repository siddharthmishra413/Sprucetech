import React from 'react';
import './App.css';
import {BrowserRouter, Route} from 'react-router-dom'
import WrappedNormalLoginForm from './components/Login';
import WrappedRegistrationForm from './components/Register';
import WrappedForgotForm from './components/Forgot';
import WrappedResetForm from './components/Reset';
import Awards from './components/Awards';
import About from './components/About';
import Users from './components/Users';



function App() {
  return (

    <BrowserRouter>
    
    <div>
      <Route exact path='/' component={WrappedNormalLoginForm} />
      <Route path='/register' component={WrappedRegistrationForm} />
      <Route path='/forgot' component={WrappedForgotForm} />
      <Route path='/reset' component={WrappedResetForm} />
      <Route path='/awards' component={Awards} />
      <Route path='/about' component={About} />
      <Route path='/users' component={Users} />
    </div>
    </BrowserRouter>
      
  );
}

export default App;
