import React, { Component } from 'react'
import { Layout } from 'antd';
import HeaderComp from '../components/Header';
import FooterComp from '../components/Footer';
import { Table } from 'antd';
import icon_entrant from '../icon_entrant.png';
import icon_clioadmin from '../icon_clioadmin.png';
import icon_juror from '../icon_juror.png';
import { Tag } from 'antd';




const { Content } = Layout;


const columns = [
    {
        title: '',
        dataIndex: 'roleIcon',
        key: 'roleIcon',
        className: 'roleicon',
        render: text => <img alt={text} src={text} />
    },
    {
      title: 'First Name',
      dataIndex: 'firstName',
      key: 'firstName',
    },
    {
        title: 'Last Name',
        dataIndex: 'lastName',
        key: 'lastName',
    },
    {
        title: 'userName',
        dataIndex: 'userName',
        key: 'userName',
    },
    {
        title: 'email',
        dataIndex: 'email',
        key: 'email',
    },
    {
        title: 'titlerole',
        dataIndex: 'titlerole',
        key: 'titlerole',
    },
    {
        title: 'companyname',
        dataIndex: 'companyname',
        key: 'companyname',
    },
    {
        title: 'companyaddress',
        dataIndex: 'companyaddress',
        key: 'companyaddress',
    },
    {
        title: 'phone',
        dataIndex: 'phone',
        key: 'phone',
    },
    {
      title: 'Role',
      dataIndex: 'role',
      key: 'role',
      className: 'role',
    },
    
  ];
  
  const data = [
    {
        key: '1',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'abc@gmail.com',
        titlerole: 'Developer',
        companyname: 'Web Company',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        roleIcon: icon_entrant,
        role: 'Entrant',
    },
    
    {
        key: '2',
        firstName: 'Jim',
        lastName: 'Green',
        userName: 'jim',
        email: 'def@gmail.com',
        titlerole: 'Musician',
        companyname: 'Music Company',
        companyaddress: 'London No. 1 Lake Park',
        phone: '222222222',
        roleIcon: icon_entrant,
        role: 'Entrant',
    },
    {
        key: '3',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'ghi@gmail.com',
        titlerole: 'Designer',
        companyname: 'Design Company',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        roleIcon: icon_juror,
        role: 'Juror',
    },
    {
        key: '4',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'jkl@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        roleIcon: icon_clioadmin,
        role: 'Clio Admin',
    },
    {
        key: '5',
        firstName: 'Jim',
        lastName: 'Green',
        userName: 'jim',
        email: 'def@gmail.com',
        titlerole: 'Musician',
        companyname: 'Music Company',
        companyaddress: 'London No. 1 Lake Park',
        phone: '222222222',
        roleIcon: icon_entrant,
        role: 'Entrant',
    },
    {
        key: '6',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'ghi@gmail.com',
        titlerole: 'Designer',
        companyname: 'Design Company',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        roleIcon: icon_juror,
        role: 'Juror',
    },
    {
        key: '7',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'jkl@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        roleIcon: icon_clioadmin,
        role: 'Clio Admin',
    },
    {
        key: '8',
        firstName: 'Jim',
        lastName: 'Green',
        userName: 'jim',
        email: 'def@gmail.com',
        titlerole: 'Musician',
        companyname: 'Music Company',
        companyaddress: 'London No. 1 Lake Park',
        phone: '222222222',
        roleIcon: icon_entrant,
        role: 'Entrant',
    },
    {
        key: '9',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'ghi@gmail.com',
        titlerole: 'Designer',
        companyname: 'Design Company',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        roleIcon: icon_juror,
        role: 'Juror',
    },
    {
        key: '10',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'jkl@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        roleIcon: icon_clioadmin,
        role: 'Clio Admin',
    }
  ];



class Users extends Component {
    render() {
        return (
            <Layout>
                <div className="innerCont users">
                    <HeaderComp />
                    <Content>

                        <h1>Registered Users</h1>
                        <Tag color="volcano"><img src={icon_clioadmin} alt={icon_clioadmin} /><span>Clio Admin</span></Tag>
                        <Tag color="green"><img src={icon_juror} alt={icon_juror} /><span>Juror</span></Tag>
                        <Tag color="geekblue"><img src={icon_entrant} alt={icon_entrant} /><span>Entrant</span></Tag>
                        <Table columns={columns} dataSource={data} />

                    </Content>
                    <FooterComp />
                </div>
            </Layout>
        );
    }
}

export default Users

