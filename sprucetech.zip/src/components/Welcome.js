import React, {Component} from 'react'

class Welcome extends Component {
    render(){
        return <h1>Class Component</h1>
    }
}

export default Welcome