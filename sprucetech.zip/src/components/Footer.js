import React, { Component } from 'react'
import { Layout } from 'antd';
const { Footer } = Layout;



class FooterComp extends Component {
    render() {
        return (
            <Footer>Clio Awards ©2020</Footer>
        );
    }
}

export default FooterComp