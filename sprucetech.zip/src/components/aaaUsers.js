import React, { Component } from 'react'
import { Layout } from 'antd';
import HeaderComp from '../components/Header';
import FooterComp from '../components/Footer';
import { Table } from 'antd';

const { Column } = Table;


const { Content } = Layout;


const data = [
    {
        key: '1',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'sunilmehra.s@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        role: 'Entrant',
    },
    {
        key: '1',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'sunilmehra.s@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        role: 'Entrant',
    },
    {
        key: '1',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'sunilmehra.s@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        role: 'Entrant',
    },
    {
        key: '1',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'sunilmehra.s@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        role: 'Entrant',
    },
    {
        key: '1',
        firstName: 'John',
        lastName: 'Brown',
        userName: 'john',
        email: 'sunilmehra.s@gmail.com',
        titlerole: 'Entrant',
        companyname: 'Clio Awards',
        companyaddress: 'New York No. 1 Lake Park',
        phone: '111111111',
        role: 'Entrant',
    },
    
];



class Users extends Component {
    render() {
        return (
            <Layout>
                <div className="innerCont">
                    <HeaderComp />
                    <Content>
                        <h1>Registered Users</h1>

                        <Table dataSource={data}>
                            
                                <Column title="First Name" dataIndex="firstName" key="firstName" />
                                <Column title="Last Name" dataIndex="lastName" key="lastName" />
                            
                            <Column title="User Name" dataIndex="userName" key="userName" />
                            <Column title="Email" dataIndex="email" key="email" />
                            <Column title="Title/Role" dataIndex="titlerole" key="titlerole" />
                            <Column title="Company Name" dataIndex="companyname" key="companyname" />
                            <Column title="Company Address" dataIndex="companyaddress" key="companyaddress" />
                            <Column title="Phone" dataIndex="phone" key="phone" />
                            <Column title="User Role" dataIndex="role" key="role" />
                            
                            
                        </Table>
                    </Content>
                    <FooterComp />
                </div>
            </Layout>
        );
    }
}

export default Users