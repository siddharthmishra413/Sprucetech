import React, { Component } from 'react'
import { Layout } from 'antd';
import logo from '../logo.png';
import { Menu, Dropdown } from 'antd';
import { Avatar } from 'antd';


const { Header } = Layout;

const menu = (
    <Menu>
        <Menu.Item>
            <a href="/myaccount">
                My Account
        </a>
        </Menu.Item>
        <Menu.Item>
            <a href="/">
                Logout
        </a>
        </Menu.Item>
    </Menu>
);

class HeaderComp extends Component {
    render() {
        return (
            <Header>
                <div className="App-logo"><img src={logo} alt="logo" /></div>
                <div className="projectName">Nemo</div>
                <div className="navbar">
                    <div className="l">
                        <a href="/awards">Awards</a>
                        <a href="/about">About Clio</a>
                        <a href="/users">Registered Users</a>
                    </div>
                    <div className="m">
                        <Dropdown overlay={menu}>
                            <div className="ant-dropdown-link">
                                <Avatar icon="user" />
                            </div>
                        </Dropdown>
                    </div>
                    <div className="r">Welcome! Sunil Mehra <span>(Administrator)</span></div>
                    <div className="clear"></div>
                </div>
            </Header>
        );
    }
}

export default HeaderComp